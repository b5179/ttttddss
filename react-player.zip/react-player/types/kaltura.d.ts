import BaseReactPlayer, { BaseReactPlayerProps } from './base'

export interface KalturaPlayerProps extends BaseReactPlayerProps {}

export default class KalturaPlayer extends BaseReactPlayer<KalturaPlayerProps> {}
